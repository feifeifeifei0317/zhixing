# AI集成快速开始指南

## 第一步：选择AI服务提供商

### 推荐方案：百度AI（国内，成本低，效果好）

1. **百度文心一言**（文本转PPT增强）
   - 注册：https://cloud.baidu.com/product/wenxinworkshop
   - 获取 API Key 和 Secret Key

2. **百度语音合成**（TTS）
   - 注册：https://cloud.baidu.com/product/speech
   - 开通语音合成服务
   - 获取 API Key 和 Secret Key

3. **腾讯云数字人**（AI数字形象）
   - 注册：https://cloud.tencent.com/product/dh
   - 开通数字人服务
   - 创建数字人形象
   - 获取 SecretId、SecretKey 和 AvatarId

## 第二步：安装依赖

```bash
cd backend
pip install -r requirements-ai.txt
pip install python-dotenv
```

## 第三步：配置环境变量

1. 复制示例配置文件：
```bash
cd backend
copy env.example .env
```

2. 编辑 `.env` 文件，填入你的API密钥：
```env
# 百度文心一言
BAIDU_WENXIN_API_KEY=你的API_KEY
BAIDU_WENXIN_SECRET_KEY=你的SECRET_KEY

# 百度语音合成
BAIDU_TTS_API_KEY=你的API_KEY
BAIDU_TTS_SECRET_KEY=你的SECRET_KEY

# 腾讯云数字人
TENCENT_SECRET_ID=你的SECRET_ID
TENCENT_SECRET_KEY=你的SECRET_KEY
TENCENT_REGION=ap-beijing
TENCENT_AVATAR_ID=你的AVATAR_ID

# 启用AI
ENABLE_AI_ENHANCEMENT=true
AI_PROVIDER=baidu
```

## 第四步：重启后端服务

```bash
# 停止现有服务
# 然后重新启动
cd backend
python main.py
```

## 第五步：测试

1. 访问 http://localhost:3000
2. 测试"文本转PPT"功能（应该会使用AI增强）
3. 测试"PPT转视频"功能（应该会生成AI数字人讲解）

## 常见问题

### Q: 如何知道AI服务是否启用？
A: 查看后端启动日志，如果看到"✓ AI增强服务已启用"说明配置成功。

### Q: API密钥在哪里获取？
A: 
- 百度AI：https://console.bce.baidu.com/ai/
- 腾讯云：https://console.cloud.tencent.com/

### Q: 如何测试单个服务？
A: 可以单独测试：
- 只配置百度文心一言 → 测试文本转PPT
- 只配置百度TTS → 测试语音生成
- 只配置腾讯云数字人 → 测试数字人视频

### Q: 成本如何？
A: 详见 `AI_INTEGRATION_GUIDE.md` 中的成本估算部分。

## 下一步

- 查看 `AI_INTEGRATION_GUIDE.md` 了解详细集成方案
- 查看 `backend/services/ai_service.py` 了解代码实现
- 根据需要调整AI服务提供商

 






