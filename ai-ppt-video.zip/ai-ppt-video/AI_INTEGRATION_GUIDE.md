# AI集成完整指南

本文档详细说明如何集成外部AI服务来实现教材制作系统的所有功能。

## 功能需求与AI服务对应

### 1. 文本转PPT - 需要AI增强
**当前实现**：简单的文本解析和PPT生成
**AI增强方案**：
- **大语言模型（LLM）**：用于理解文本内容、生成更好的PPT结构、优化内容组织
- **可选服务**：
  - OpenAI GPT-4/GPT-3.5
  - 百度文心一言
  - 阿里通义千问
  - 腾讯混元
  - 智谱AI GLM

### 2. PPT转视频 - 需要AI增强
**当前实现**：将PPT幻灯片转为图片，合成为视频
**AI增强方案**：
- **TTS（文本转语音）**：将PPT文本转换为语音
- **可选服务**：
  - Azure Cognitive Services TTS
  - 百度语音合成
  - 讯飞语音合成
  - 腾讯云语音合成
  - 阿里云语音合成

### 3. AI数字形象讲解 - 需要完整AI集成
**当前实现**：占位符，未实现
**AI集成方案**：
- **数字人服务**：生成AI数字人讲解视频
- **可选服务**：
  - 腾讯云数字人
  - 阿里云数字人
  - 百度智能云数字人
  - 讯飞数字人
  - 开源方案：SadTalker

## 推荐方案（成本与效果平衡）

### 方案A：国内服务（推荐）
- **文本转PPT增强**：百度文心一言 或 阿里通义千问
- **TTS服务**：百度语音合成 或 讯飞语音合成
- **数字人服务**：腾讯云数字人 或 阿里云数字人

### 方案B：国际服务
- **文本转PPT增强**：OpenAI GPT-4
- **TTS服务**：Azure Cognitive Services TTS
- **数字人服务**：需要国内替代方案（国际服务较少）

### 方案C：混合方案
- **文本转PPT增强**：OpenAI GPT-3.5（成本较低）
- **TTS服务**：百度语音合成（中文效果好）
- **数字人服务**：腾讯云数字人（国内服务稳定）

## 集成步骤

### 第一步：注册AI服务账号并获取API密钥

#### 1.1 百度文心一言（文本转PPT增强）
1. 访问：https://cloud.baidu.com/product/wenxinworkshop
2. 注册账号并创建应用
3. 获取 API Key 和 Secret Key

#### 1.2 百度语音合成（TTS）
1. 访问：https://cloud.baidu.com/product/speech
2. 开通语音合成服务
3. 获取 API Key 和 Secret Key

#### 1.3 腾讯云数字人
1. 访问：https://cloud.tencent.com/product/dh
2. 开通数字人服务
3. 获取 SecretId 和 SecretKey
4. 创建数字人形象并获取 AvatarId

### 第二步：安装必要的SDK

```bash
# 进入后端目录
cd backend

# 安装百度AI SDK
pip install baidu-aip

# 安装腾讯云SDK
pip install tencentcloud-sdk-python

# 安装OpenAI SDK（如果使用）
pip install openai

# 安装Azure SDK（如果使用Azure TTS）
pip install azure-cognitiveservices-speech
```

### 第三步：创建配置文件

创建 `backend/.env` 文件（不要提交到Git）：

```env
# 百度文心一言配置
BAIDU_WENXIN_API_KEY=your_api_key
BAIDU_WENXIN_SECRET_KEY=your_secret_key

# 百度语音合成配置
BAIDU_TTS_API_KEY=your_api_key
BAIDU_TTS_SECRET_KEY=your_secret_key

# 腾讯云数字人配置
TENCENT_SECRET_ID=your_secret_id
TENCENT_SECRET_KEY=your_secret_key
TENCENT_REGION=ap-beijing
TENCENT_AVATAR_ID=your_avatar_id

# OpenAI配置（可选）
OPENAI_API_KEY=your_openai_api_key
OPENAI_BASE_URL=https://api.openai.com/v1

# Azure TTS配置（可选）
AZURE_SPEECH_KEY=your_azure_key
AZURE_SPEECH_REGION=your_region
```

### 第四步：修改代码集成AI服务

详见下面的代码实现部分。

## 成本估算

### 百度文心一言
- 免费额度：每月200万tokens
- 付费：约0.012元/千tokens
- 单次PPT生成：约500-2000 tokens

### 百度语音合成
- 免费额度：每月5万字符
- 付费：约0.03元/千字符
- 单次视频：约500-2000字符

### 腾讯云数字人
- 按分钟计费：约0.5-2元/分钟
- 单次视频：约1-5分钟

**总体估算**：单次完整流程（文本→PPT→视频+数字人）约 2-10元

## 注意事项

1. **API密钥安全**：不要将`.env`文件提交到Git，使用环境变量
2. **成本控制**：设置使用量限制和告警
3. **错误处理**：添加完善的错误处理和重试机制
4. **缓存机制**：对相同内容进行缓存，避免重复调用
5. **异步处理**：视频生成耗时较长，考虑使用异步任务队列








