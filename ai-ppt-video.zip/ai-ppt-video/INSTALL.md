# 安装指南

## 系统要求

- Node.js 16+ 
- Python 3.8+
- FFmpeg (用于视频处理)

## 安装FFmpeg

### Windows
1. 下载FFmpeg：https://ffmpeg.org/download.html
2. 解压到任意目录（如 `C:\ffmpeg`）
3. 将 `C:\ffmpeg\bin` 添加到系统环境变量 PATH 中
4. 验证安装：在命令行运行 `ffmpeg -version`

### macOS
```bash
brew install ffmpeg
```

### Linux
```bash
sudo apt-get update
sudo apt-get install ffmpeg
```

## 安装步骤

### 1. 安装前端依赖

```bash
npm install
```

### 2. 安装后端依赖

```bash
cd backend
pip install -r requirements.txt
```

### 3. 创建必要的目录

```bash
# Windows
mkdir temp

# Linux/macOS
mkdir -p temp
```

## 运行项目

### 方式一：使用启动脚本（Windows）

1. 双击 `start-backend.bat` 启动后端（端口8000）
2. 双击 `start-frontend.bat` 启动前端（端口3000）

### 方式二：手动启动

**终端1 - 启动后端：**
```bash
cd backend
python main.py
```

**终端2 - 启动前端：**
```bash
npm run dev
```

## 访问应用

打开浏览器访问：http://localhost:3000

## 常见问题

### 1. Python模块导入错误

如果遇到 `ModuleNotFoundError`，确保：
- 已安装所有依赖：`pip install -r requirements.txt`
- 在 `backend` 目录下运行 `main.py`

### 2. FFmpeg未找到

确保FFmpeg已正确安装并添加到PATH环境变量中。

### 3. 端口被占用

如果3000或8000端口被占用：
- 修改 `vite.config.ts` 中的端口（前端）
- 修改 `backend/main.py` 中的端口（后端）

### 4. CORS错误

确保后端CORS配置中包含前端地址（默认已配置 `http://localhost:3000`）

## 开发模式

前端支持热重载，修改代码后会自动刷新。

后端修改代码后需要重启服务器。

## 生产部署

### 前端构建

```bash
npm run build
```

构建产物在 `dist` 目录。

### 后端部署

推荐使用 Gunicorn 或 uWSGI：

```bash
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker
```










