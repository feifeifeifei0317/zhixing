import axios from 'axios'

const API_BASE_URL = '/api'

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 300000, // 5分钟超时，因为生成视频可能需要较长时间
})

export const textToPPT = async (text: string): Promise<File> => {
  const formData = new FormData()
  formData.append('text', text)
  
  const response = await api.post(
    '/text-to-ppt',
    formData,
    {
      responseType: 'blob',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    }
  )
  
  const blob = new Blob([response.data], {
    type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  })
  
  return new File([blob], `presentation_${Date.now()}.pptx`, {
    type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  })
}

export const pptToVideo = async (
  pptFile: File,
  aiAvatarEnabled: boolean
): Promise<string> => {
  const formData = new FormData()
  formData.append('file', pptFile)
  formData.append('ai_avatar_enabled', String(aiAvatarEnabled))

  const response = await api.post(
    '/ppt-to-video',
    formData,
    {
      responseType: 'blob',
    }
  )

  const blob = new Blob([response.data], { type: 'video/mp4' })
  return URL.createObjectURL(blob)
}



