import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import MaterialCreator from './pages/MaterialCreator'
import './App.css'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<MaterialCreator />} />
      </Routes>
    </Router>
  )
}

export default App










