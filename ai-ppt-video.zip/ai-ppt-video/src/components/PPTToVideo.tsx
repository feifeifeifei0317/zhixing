import { useState } from 'react'
import { pptToVideo } from '../services/api'
import './PPTToVideo.css'

interface PPTToVideoProps {
  onVideoGenerated?: (url: string | null) => void
}

const PPTToVideo = ({ onVideoGenerated }: PPTToVideoProps) => {
  const [pptFile, setPptFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [aiAvatarEnabled, setAiAvatarEnabled] = useState(true)

  const handleGenerateVideo = async () => {
    if (!pptFile) {
      setError('请先上传PPT文件')
      return
    }

    setLoading(true)
    setError(null)

    try {
      const videoUrl = await pptToVideo(pptFile, aiAvatarEnabled)
      onVideoGenerated?.(videoUrl)
    } catch (err: any) {
      setError(err.message || '生成视频失败，请重试')
      onVideoGenerated?.(null)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="ppt-to-video">
      <h2>PPT转视频</h2>
      <p className="description">直接上传PPT，即可生成带AI讲解的视频</p>

      <div className="upload">
        <label className="upload-btn">
          <input
            type="file"
            accept=".ppt,.pptx"
            onChange={(e) => {
              const file = e.target.files?.[0]
              setPptFile(file ?? null)
              setError(null)
            }}
            disabled={loading}
          />
          选择PPT文件
        </label>
        {pptFile && (
          <div className="file-info">
            <div className="file-icon">📄</div>
            <div className="file-details">
              <div className="file-name">{pptFile.name}</div>
              <div className="file-size">{(pptFile.size / 1024).toFixed(2)} KB</div>
            </div>
          </div>
        )}
      </div>

      <div className="options">
        <label className="option-item">
          <input
            type="checkbox"
            checked={aiAvatarEnabled}
            onChange={(e) => setAiAvatarEnabled(e.target.checked)}
            disabled={loading}
          />
          <span>启用AI数字形象讲解</span>
        </label>
        <p className="option-hint">AI数字形象将在视频中自动讲解PPT内容（可接入真实数字人）</p>
      </div>

      {error && <div className="error-message">{error}</div>}

      <div className="actions single">
        <button 
          className="generate-btn"
          onClick={handleGenerateVideo}
          disabled={loading || !pptFile}
        >
          {loading ? '正在生成视频...' : '生成视频'}
        </button>
      </div>
    </div>
  )
}

export default PPTToVideo


