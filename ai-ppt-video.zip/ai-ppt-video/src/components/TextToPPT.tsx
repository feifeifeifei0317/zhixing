import { useState } from 'react'
import { textToPPT } from '../services/api'
import './TextToPPT.css'

interface TextToPPTProps {
  onPPTGenerated?: (file: File) => void
}

const TextToPPT = ({ onPPTGenerated }: TextToPPTProps) => {
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!text.trim()) {
      setError('请输入文本内容')
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const file = await textToPPT(text)
      // 自动下载
      const url = URL.createObjectURL(file)
      const a = document.createElement('a')
      a.href = url
      a.download = file.name
      a.click()
      URL.revokeObjectURL(url)

      onPPTGenerated?.(file)
      setSuccess('PPT 已生成并开始下载')
    } catch (err: any) {
      setError(err.message || '生成PPT失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="text-to-ppt">
      <h2>文本转PPT</h2>
      <p className="description">输入课程文本，一键生成并自动下载 PPT</p>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="text-input">课程文本内容</label>
          <textarea
            id="text-input"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="请输入您的课程内容，例如：&#10;&#10;第一章：课程介绍&#10;1.1 课程目标&#10;1.2 课程大纲&#10;&#10;第二章：基础知识&#10;2.1 核心概念&#10;2.2 重要原理..."
            rows={15}
            disabled={loading}
          />
          <div className="char-count">{text.length} 字符</div>
        </div>

        {error && <div className="error-message">{error}</div>}
        {success && <div className="success-message">{success}</div>}

        <button 
          type="submit" 
          className="submit-btn"
          disabled={loading || !text.trim()}
        >
          {loading ? '正在生成PPT...' : '生成并下载PPT'}
        </button>
      </form>
    </div>
  )
}

export default TextToPPT


