import { useState } from 'react'
import './VideoPreview.css'

interface VideoPreviewProps {
  videoUrl: string | null
  onBack: () => void
}

const VideoPreview = ({ videoUrl, onBack }: VideoPreviewProps) => {
  const [downloading, setDownloading] = useState(false)

  const handleDownload = async () => {
    setDownloading(true)
    try {
      const response = await fetch(videoUrl)
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `课程视频_${new Date().getTime()}.mp4`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      window.URL.revokeObjectURL(url)
    } catch (err) {
      console.error('下载失败:', err)
    } finally {
      setDownloading(false)
    }
  }

  const hasVideo = Boolean(videoUrl)

  return (
    <div className="video-preview">
      <h2>视频预览</h2>
      <p className="description">
        {hasVideo ? '您的课程视频已生成完成，包含AI数字形象讲解' : '生成后可在此预览视频、重新生成或下载'}
      </p>

      {hasVideo ? (
        <>
          <div className="video-container">
            <video
              src={videoUrl ?? undefined}
              controls
              className="video-player"
              poster=""
            >
              您的浏览器不支持视频播放
            </video>
          </div>

          <div className="video-info">
            <div className="info-item">
              <span className="info-label">状态：</span>
              <span className="info-value success">✓ 生成成功</span>
            </div>
            <div className="info-item">
              <span className="info-label">AI讲解：</span>
              <span className="info-value">✓ 已启用</span>
            </div>
          </div>
        </>
      ) : (
        <div className="video-placeholder">
          <div className="placeholder-icon">🎬</div>
          <div className="placeholder-text">
            <p className="placeholder-title">暂无视频可预览</p>
            <p className="placeholder-desc">请先在 “PPT转视频” 模块上传 PPT 并点击生成</p>
          </div>
        </div>
      )}

      <div className="actions">
        <button
          className="back-btn"
          onClick={onBack}
          disabled={!hasVideo}
        >
          重新生成
        </button>
        <button
          className="download-btn"
          onClick={handleDownload}
          disabled={!hasVideo || downloading}
        >
          {downloading ? '下载中...' : hasVideo ? '下载视频' : '等待生成'}
        </button>
      </div>
    </div>
  )
}

export default VideoPreview










