import { useState } from 'react'
import TextToPPT from '../components/TextToPPT'
import PPTToVideo from '../components/PPTToVideo'
import VideoPreview from '../components/VideoPreview'
import './MaterialCreator.css'

const MaterialCreator = () => {
  const [videoUrl, setVideoUrl] = useState<string | null>(null)

  return (
    <div className="material-creator">
      <div className="container">
        <h1 className="title">教材制作系统</h1>
        <p className="subtitle">AI驱动的智能教材制作工具</p>

        <div className="grid">
          <div className="card">
            <TextToPPT onPPTGenerated={() => { /* 下载已在组件内处理 */ }} />
          </div>

          <div className="card">
            <PPTToVideo onVideoGenerated={setVideoUrl} />
          </div>

          <div className="card">
            <VideoPreview videoUrl={videoUrl} onBack={() => setVideoUrl(null)} />
          </div>
        </div>
      </div>
    </div>
  )
}

export default MaterialCreator


