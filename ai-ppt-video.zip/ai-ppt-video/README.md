# 线上课程系统 - 教材制作模块

这是一个基于AI的智能教材制作系统，支持文本转PPT、PPT转视频，以及AI数字形象讲解功能。

## 功能特性

- 📝 **文本转PPT**: 输入课程文本，AI自动生成精美的PPT演示文稿
- 🎬 **PPT转视频**: 将PPT转换为视频格式，便于在线播放
- 🤖 **AI数字形象讲解**: 集成AI数字人，自动为视频添加讲解

## 技术栈

### 前端
- React 18
- TypeScript
- Vite
- Axios

### 后端
- Python 3.8+
- FastAPI
- python-pptx (PPT生成)
- MoviePy (视频处理)
- OpenCV (图像处理)

## 项目结构

```
线上课程系统/
├── src/                    # 前端源代码
│   ├── components/         # React组件
│   ├── pages/             # 页面组件
│   ├── services/          # API服务
│   └── main.tsx           # 入口文件
├── backend/               # 后端源代码
│   ├── services/          # 业务逻辑服务
│   └── main.py           # FastAPI主文件
├── package.json           # 前端依赖
├── requirements.txt       # 后端依赖
└── README.md             # 项目说明
```

## 安装和运行

### 前端

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端将在 http://localhost:3000 运行

### 后端

```bash
# 进入后端目录
cd backend

# 安装Python依赖
pip install -r requirements.txt

# 启动FastAPI服务器
python main.py
```

后端API将在 http://localhost:8000 运行

## 使用说明

1. **文本转PPT**
   - 在文本输入框中输入课程内容
   - 点击"生成PPT"按钮
   - 系统会自动解析文本结构，生成PPT文件

2. **PPT转视频**
   - 上传生成的PPT文件
   - 选择是否启用AI数字形象讲解
   - 点击"生成视频"按钮
   - 系统会将PPT转换为视频格式

3. **视频预览和下载**
   - 预览生成的视频
   - 下载最终视频文件

## AI数字形象集成说明

当前版本中，AI数字形象功能为占位符实现。要启用完整的AI数字人功能，需要：

1. **选择数字人服务提供商**：
   - 腾讯云数字人
   - 阿里云数字人
   - 百度智能云数字人
   - 或使用开源方案（如SadTalker）

2. **集成步骤**：
   - 在 `backend/services/ppt_to_video.py` 的 `_add_ai_avatar` 方法中
   - 调用数字人API生成讲解视频
   - 将数字人视频与PPT视频合成

3. **TTS（文本转语音）**：
   - 需要集成TTS服务（如Azure TTS、百度TTS等）
   - 将PPT文本转换为语音
   - 驱动数字人进行讲解

## 注意事项

- 确保已安装FFmpeg（用于视频处理）
- 生成视频可能需要较长时间，请耐心等待
- AI数字形象功能需要额外的API密钥和服务配置

## 开发计划

- [ ] 完善PPT样式和模板
- [ ] 集成真实的AI数字人服务
- [ ] 添加更多视频导出选项
- [ ] 优化视频生成性能
- [ ] 添加进度条显示

## 许可证

MIT License










